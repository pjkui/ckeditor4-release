﻿/*
 Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","km",{title:"ប្រដាប់​រើស​ពណ៌",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"ឈុត​ពណ៌​កំណត់​រួច​ស្រេច",config:"បិទ​ភ្ជាប់​ខ្សែ​អក្សរ​នេះ​ទៅ​ក្នុង​ឯកសារ config.js របស់​អ្នក"});